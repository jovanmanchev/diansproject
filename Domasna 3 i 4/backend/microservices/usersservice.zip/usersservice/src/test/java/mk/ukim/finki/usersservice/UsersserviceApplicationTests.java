package mk.ukim.finki.usersservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
